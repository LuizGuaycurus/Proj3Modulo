
package ClassesConsultorio;

public class Dentista {
    private String nome;
    private String Cro;
    private String Especialidade;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCro() {
        return Cro;
    }

    public void setCro(String Cro) {
        this.Cro = Cro;
    }

    public String getEspecialidade() {
        return Especialidade;
    }

    public void setEspecialidade(String Especialidade) {
        this.Especialidade = Especialidade;
    }
    
    
}
