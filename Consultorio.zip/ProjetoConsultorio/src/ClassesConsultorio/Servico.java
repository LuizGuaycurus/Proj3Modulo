
package ClassesConsultorio;

public class Servico {
    private int IdServico;
    private String Tratamento;
    private String Especialidade;
    private double Preco;

    public int getIdServico() {
        return IdServico;
    }

    public void setIdServico(int IdServico) {
        this.IdServico = IdServico;
    }

    public String getTratamento() {
        return Tratamento;
    }

    public void setTratamento(String Tratamento) {
        this.Tratamento = Tratamento;
    }

    public String getEspecialidade() {
        return Especialidade;
    }

    public void setEspecialidade(String Especialidade) {
        this.Especialidade = Especialidade;
    }

    public double getPreco() {
        return Preco;
    }

    public void setPreco(double Preco) {
        this.Preco = Preco;
    }
    
    
}
