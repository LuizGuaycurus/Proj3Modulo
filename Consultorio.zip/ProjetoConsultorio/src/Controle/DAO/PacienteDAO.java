
package Controle.DAO;

import ClassesConsultorio.Paciente;
import Controle.FabricaDeConexoes;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class PacienteDAO {
    private Connection conn;
    
    public PacienteDAO(java.sql.Connection conn){
        
        conn = new FabricaDeConexoes().getConnection();
        
    }
    
    public void InserirPaciente(Paciente paciente) throws SQLException{
        String sql = "insert into paciente(cpf,nome,cep,numerocasa,complemento,dataNasc) values(?,?,?,?,?,?)";
        
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, paciente.getCpf());
        stmt.setString(2, paciente.getNome());
        stmt.setString(3, paciente.getCep());
        stmt.setString(4, paciente.getNumerocasa());
        stmt.setString(5, paciente.getComplementocasa());
        stmt.setString(6, paciente.getDataNascimento());
        
        stmt.execute();
	stmt.close();
	conn.close();
    }
    
    public void ExcluirPaciente(Paciente paciente) throws SQLException{
    String sql = "delete from paciente where cpf=?";
    
    PreparedStatement stmt = conn.prepareStatement(sql);
    stmt.setString(1, paciente.getCpf());
    
    stmt.execute();
    stmt.close();
    conn.close();
    }
    
    public void AlterarPaciente(Paciente paciente) throws SQLException{
    
    String sql = "update paciente set nome=?,cep=?,numerocasa=?,complemento=?,dataNasc=? where cpf=?";    
    
    PreparedStatement stmt = conn.prepareStatement(sql);
    stmt.setString(1, paciente.getNome());
    stmt.setString(2, paciente.getCep());
    stmt.setString(3, paciente.getNumerocasa());
    stmt.setString(4, paciente.getComplementocasa());
    stmt.setString(5, paciente.getDataNascimento());
    stmt.setString(6, paciente.getCpf());
    
    stmt.executeUpdate();
    stmt.close();
    conn.close();
    }
    
    public List ListarPaciente() throws SQLException{
    String sql = "select * from paciente";
    
    PreparedStatement stmt = conn.prepareStatement(sql);
    
        ResultSet rs = stmt.executeQuery();
        
        List<Paciente> paciente = new ArrayList<Paciente>();
        
        while(rs.next()){
        Paciente pt = new Paciente();
        pt.setCpf(rs.getString("cpf"));
        pt.setNome(rs.getString("nome"));
        pt.setCep(rs.getString("cep"));
        pt.setNumerocasa(rs.getString("numerocasa"));
        pt.setComplementocasa(rs.getString("complemento"));
        pt.setDataNascimento(rs.getString("dataNasc"));
        
        paciente.add(pt);
        }
        return paciente;
    }
    
    
}
