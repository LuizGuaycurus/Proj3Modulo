package ClassesConsultorio;

public class Consulta {
    private String hora;
    private String data;
    private String descricao;
    private int IdConsulta;
    private Paciente paciente;
    private Dentista Cro;

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public int getIdConsulta() {
        return IdConsulta;
    }

    public void setIdConsulta(int IdConsulta) {
        this.IdConsulta = IdConsulta;
    }

    public String getPaciente() {
        return paciente.getCpf();
    }

    public void setPaciente(Paciente paciente) {
        this.paciente = paciente;
    }

    /**
     * @return the Cro
     */
    public String getCro() {
        return Cro.getCro();
    }

    public void setCro(Dentista Cro) {
        this.Cro = Cro;
    }
    
    
}
