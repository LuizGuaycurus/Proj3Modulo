
package ClassesConsultorio;


public class Paciente {
    private String Nome;
    private String Telefone;
    private String Consulta;
    private String Cpf;
    private String Cep;
    private String Numerocasa;
    private String Complementocasa;
    private String DataNascimento;

    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    public String getTelefone() {
        return Telefone;
    }

    public void setTelefone(String Telefone) {
        this.Telefone = Telefone;
    }
    

    public String getConsulta() {
        return Consulta;
    }

    public void setConsulta(String Consulta) {
        this.Consulta = Consulta;
    }

    public String getCpf() {
        return Cpf;
    }

    public void setCpf(String Cpf) {
        this.Cpf = Cpf;
    }

    public String getCep() {
        return Cep;
    }

    public void setCep(String Cep) {
        this.Cep = Cep;
    }

    public String getNumerocasa() {
        return Numerocasa;
    }

    public void setNumerocasa(String Numerocasa) {
        this.Numerocasa = Numerocasa;
    }

    public String getComplementocasa() {
        return Complementocasa;
    }

    public void setComplementocasa(String Complementocasa) {
        this.Complementocasa = Complementocasa;
    }

    public String getDataNascimento() {
        return DataNascimento;
    }

    public void setDataNascimento(String DataNascimento) {
        this.DataNascimento = DataNascimento;
    }
}
