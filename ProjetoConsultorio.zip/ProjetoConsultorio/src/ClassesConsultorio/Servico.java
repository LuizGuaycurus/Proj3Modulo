
package ClassesConsultorio;

public class Servico {
    private int IdServico;
    private String Tratamento;
    private double Preco;

    public int getIdServico() {
        return IdServico;
    }

    public void setIdServico(int IdServico) {
        this.IdServico = IdServico;
    }

    public String getTratamento() {
        return Tratamento;
    }

    public void setTratamento(String Tratamento) {
        this.Tratamento = Tratamento;
    }

    public double getPreco() {
        return Preco;
    }

    public void setPreco(double Preco) {
        this.Preco = Preco;
    }
    
    
}
