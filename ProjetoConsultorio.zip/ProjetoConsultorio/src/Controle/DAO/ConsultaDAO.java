package Controle.DAO;

import ClassesConsultorio.Consulta;
import ClassesConsultorio.Dentista;
import ClassesConsultorio.Paciente;
import Controle.FabricaDeConexoes;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ConsultaDAO {
    private Connection conn;
    
    public ConsultaDAO(java.sql.Connection conn){
        
        conn = new FabricaDeConexoes().getConnection();
        
    }
    
    public void InserirConsulta(Consulta consulta) throws SQLException{
    String sql = "insert into consulta(dataConsulta,horaConsulta,Cpf,croDentista) values(?,?,?,?)";
    
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, consulta.getData());
        stmt.setString(2, consulta.getHora());
        stmt.setString(3, consulta.getPaciente());
        stmt.setString(4, consulta.getCro());
        
        stmt.execute();
	stmt.close();
	conn.close();
    }
    public void ExcluirConsulta(Consulta consulta) throws SQLException{
    String sql = "delete from consulta where idConsulta=?";
    
    PreparedStatement stmt = conn.prepareStatement(sql);
    stmt.setInt(1, consulta.getIdConsulta());
    
    stmt.execute();
    stmt.close();
    conn.close();
    
    }
    public void AlterarConsulta(Consulta consulta) throws SQLException{
    String sql = "update consulta set dataConsulta=?,horaConsulta=?,cpf=?,croDentista=?";
    
    PreparedStatement stmt = conn.prepareStatement(sql);
    
    stmt.setString(1, consulta.getData());
    stmt.setString(2, consulta.getHora());
    stmt.setString(3, consulta.getPaciente());
    stmt.setString(4, consulta.getCro());
    }
    
    
    public List ListarConsula() throws SQLException{
    String sql = "select * from consulta";
    
    PreparedStatement stmt = conn.prepareStatement(sql);
    
    ResultSet rs = stmt.executeQuery();
    
    List<Consulta> consulta = new ArrayList<Consulta>();
    
    while(rs.next()){
    Consulta cs = new Consulta();
    cs.setData(rs.getString("dataConsulta"));
    cs.setHora(rs.getString("horaConsulta"));
    
    Paciente paciente = new Paciente();
    paciente.setCpf(rs.getString("Cpf"));
    cs.setPaciente(paciente);
    
    Dentista dentista = new Dentista();
    
    dentista.setCro(rs.getString("croDentista"));
    cs.setCro(dentista);
   
    }
        return consulta;
    
    }
}
