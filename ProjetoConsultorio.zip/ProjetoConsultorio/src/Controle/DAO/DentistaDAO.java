package Controle.DAO;

import ClassesConsultorio.Dentista;
import Controle.FabricaDeConexoes;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DentistaDAO {
    
    private Connection conn;
    
    public DentistaDAO(java.sql.Connection conn){
        conn = new FabricaDeConexoes().getConnection();
    }
    
    public void InserirDentista(Dentista dentista) throws SQLException{
    String sql = "insert into dentista(croDentista,nome,especialidade) values(?,?,?)";
     
    PreparedStatement stmt = conn.prepareStatement(sql);
     
    stmt.setString(1, dentista.getCro());
    stmt.setString(2, dentista.getNome());
    stmt.setString(3, dentista.getEspecialidade());
    
    stmt.execute();
    stmt.close();
    conn.close();
    }
    
    public void ExcluirDentista(Dentista dentista) throws SQLException{
    String sql = "delete from dentista where croDentista=?";
    
    PreparedStatement stmt = conn.prepareStatement(sql);
    stmt.setString(1, dentista.getCro());
    stmt.execute();
    stmt.close();
    conn.close();
    }
    
    public void AlterarDentista(Dentista dentista)throws SQLException{
    String sql = "update dentista set croDentista=?, nome=?, especialidade=?";
    
    PreparedStatement stmt = conn.prepareStatement(sql);
    
    stmt.setString(1, dentista.getCro());
    stmt.setString(2, dentista.getNome());
    stmt.setString(3, dentista.getEspecialidade());
    
    stmt.execute();
    stmt.close();
    conn.close();
    }
    public List ListarDentista(Dentista Dentista)throws SQLException{
    String sql = "select * from dentista";
    
    PreparedStatement stmt = conn.prepareStatement(sql);
    
    ResultSet rs = stmt.executeQuery();
    List<Dentista> dentista = new ArrayList<Dentista>();
    
    while(rs.next()){
    Dentista dt = new Dentista();
    dt.setCro(rs.getString("croDentista"));
    dt.setNome(rs.getString("nome"));
    dt.setEspecialidade(rs.getString("especialidade"));
    
    
    }
    return dentista;
    
    }
}
