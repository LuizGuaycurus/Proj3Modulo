
package Controle.DAO;

import Controle.FabricaDeConexoes;
import com.sun.jndi.ldap.Connection;


public class PacienteDAO {
    private Connection conn;
    
    public PacienteDAO(java.sql.Connection coon){
        coon = new FabricaDeConexoes().getConnection();
    }
    
    
}
