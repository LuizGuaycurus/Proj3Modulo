package Controle.DAO;

import ClassesConsultorio.Servico;
import Controle.FabricaDeConexoes;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class ServicoDAO {
   private Connection conn;
    
    public ServicoDAO(java.sql.Connection conn){
        conn = new FabricaDeConexoes().getConnection();
    }
    
    public void InserirServico(Servico servico) throws SQLException{
    String sql = "insert into servico(preco,especialidade) values(?,?)";
     
    PreparedStatement stmt = conn.prepareStatement(sql);
    }
}
